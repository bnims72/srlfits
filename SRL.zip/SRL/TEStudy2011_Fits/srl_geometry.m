function srl_geometry
    
    close all
    clear
    format long
    
    %Load Template Files for the begining and end of the file
    fname=input('\n What is the location of the srl file? ', 's');       % fname: name of data file
    [pathstr,bname,ext,versn] = fileparts(fname);            % debug parts of filename
    
    if isequal(pathstr, '')
        connt = '';
    else
        connt = '/';
    end
    
    connt;

    %Ask user for Peak time and Geometry
    
    peaktime = input('What is the SRL peak time? ');
    srldisp = input('What is the SRL ramp displacement (mm; >0)? ');
    diameter = input('What is the diameter (mm)? ');
    thickness = input('What is the thickness (mm)? ');
    
    Rad = diameter/2;
    
    %Upload positions (currently uses a function calling the generic
    %corrdinates for a 4 mm diam, 2.34 mm thick construct and
    %scales these positions - here there are 20 elements in the
    %radial direction and 1 element in the height (z)). These will
    %then be scaled according user defined parameters.
    xnode_orig = [0.0000000
0.3120967
0.3116690
0.5773789
0.5765877
0.8028688
0.8017685
0.9945352
0.9931722
1.1574517
1.1558654
1.2959306
1.2941546
1.4136378
1.4117004
1.5136888
1.5116144
1.5987322
1.5965412
1.6710191
1.6687290
1.7324630
1.7300887
1.7846902
1.7822444
1.8290834
1.8265767
1.8668176
1.8642592
1.8988917
1.8962893
1.9261547
1.9235150
1.9493282
1.9466567
1.9690257
1.9663272
1.9857686
1.9830471
2.0000000
1.9972591
0.0000000
0.3120967
0.3116690
0.5773789
0.5765877
0.8028688
0.8017685
0.9945352
0.9931722
1.1574517
1.1558654
1.2959306
1.2941546
1.4136378
1.4117004
1.5136888
1.5116144
1.5987322
1.5965412
1.6710191
1.6687290
1.7324630
1.7300887
1.7846902
1.7822444
1.8290834
1.8265767
1.8668176
1.8642592
1.8988917
1.8962893
1.9261547
1.9235150
1.9493282
1.9466567
1.9690257
1.9663272
1.9857686
1.9830471
2.0000000
1.9972591
-2.5000000
-2.5000000
2.5000000
2.5000000
-2.4965738
-2.4965738
2.4965738
2.4965738];
    
    ynode_orig = [0.0000000
0.0000000
0.0163339
0.0000000
0.0302177
0.0000000
0.0420189
0.0000000
0.0520500
0.0000000
0.0605763
0.0000000
0.0678238
0.0000000
0.0739841
0.0000000
0.0792204
0.0000000
0.0836712
0.0000000
0.0874544
0.0000000
0.0906701
0.0000000
0.0934035
0.0000000
0.0957268
0.0000000
0.0977017
0.0000000
0.0993803
0.0000000
0.1008072
0.0000000
0.1020200
0.0000000
0.1030508
0.0000000
0.1039271
0.0000000
0.1046719
0.0000000
0.0000000
0.0163339
0.0000000
0.0302177
0.0000000
0.0420189
0.0000000
0.0520500
0.0000000
0.0605763
0.0000000
0.0678238
0.0000000
0.0739841
0.0000000
0.0792204
0.0000000
0.0836712
0.0000000
0.0874544
0.0000000
0.0906701
0.0000000
0.0934035
0.0000000
0.0957268
0.0000000
0.0977017
0.0000000
0.0993803
0.0000000
0.1008072
0.0000000
0.1020200
0.0000000
0.1030508
0.0000000
0.1039271
0.0000000
0.1046719
0.2500000
-0.2500000
0.2500000
-0.2500000
-0.1308400
-0.1308398
0.1308398
0.1308400];
    
    znode_orig = [0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
-2.5000000
2.5000000
-2.5000000
2.5000000]; 

    xnode = xnode_orig;
    ynode = ynode_orig;
    znode = znode_orig;
    
    for i = 1:82;
        znode(i) = znode(i) * thickness / 2.34;
        
        if isequal(ynode(i), 0)
            xnode(i) = xnode(i) * Rad / 2;
            
        else
            h = sqrt(xnode(i) ^ 2 + ynode(i) ^2);
            xnode(i) = cosd(3) * h * (Rad / 2);
            ynode(i) = sind(3) * h * (Rad / 2);
            
        end
    end
    
    for i = 83:86;
        znode(i) = znode(i) * thickness / 2.34;
    end
    
    [xnode_orig,ynode_orig,znode_orig,xnode,ynode,znode];
    
    filetoopen1 = strcat(pathstr,connt,'TEMPLATE1_srl.feb');
    feb = fopen(filetoopen1,'a');

    
    for i = 1:length(xnode)
        fprintf(feb,'\n %s',['<node id="',num2str(i),'"> ',num2str(xnode(i)),',',num2str(ynode(i)),', ',num2str(znode(i)),'</node>']);
    end
    
    filetoopen2 = strcat(pathstr,connt,'TEMPLATE2_srl.feb');
    feb1 = fopen(filetoopen2);
    tline = fgetl(feb1);
    
    platendisp = [num2str(peaktime),',',num2str(-1*srldisp)];
    
    while ischar(tline)
            tline = strcat(tline);
            fprintf(feb,'\n %s',tline);
            tline = fgetl(feb1);
            
            %Replace XX with peak time, YY with 2*peaktime, and ZZ
            %with the platen displacement parameters
            tline = strrep(tline,'XX',num2str(peaktime));
            tline = strrep(tline,'YY',num2str(2*peaktime));
            
            tline = strrep(tline,'ZZ',platendisp);
        
    end
    
    

    fclose(feb);

    fclose(feb1);
   

