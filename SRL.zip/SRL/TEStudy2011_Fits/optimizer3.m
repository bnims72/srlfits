function optimizer3(fname,srldisp,diameter,thickness,pathstr)
    
%In optimizer2.m, we calculate the displacement of the SRL curve
%by averaging the last 100 points of the curve, rather than
%averaging the first 100 points after the peak time hits.  This was
%created to examine the affect of compliance in the system. 


    
    %Load File and find Peak Time
    
    %fname=input('\n Please enter data file name: ', 's');       % fname: name of data file
    %[pathstr,bname,ext,versn] = fileparts(fname);               %
                                                                
    %    if isequal(pathstr, '')
    %    connt = '';
    %else
    %    connt = '/';
    %end
        connt = '';
    
    
    fid=open(fname);                                            % open data file
    smoothed = filter(ones(1,5)/5,1,(fid.srl(:,3))) ;
    peakind = find(smoothed==max(smoothed));
    %peakind = find(fid.srl(:,3)==max(fid.srl(:,3)));
    peaktime_tot = fid.srl(peakind,1);
    
    %Plot Disp/Load  
    subplot(2,1,1)
    plot(fid.srl(:,1),fid.srl(:,2))
    hold on
    plot(fid.srl(peakind,1),fid.srl(peakind,2),'r+')
    subplot(2,1,2)
    plot(fid.srl(:,1),fid.srl(:,3))
    hold on
    plot(fid.srl(peakind,1),fid.srl(peakind,3),'r+')
    
    % Calculate the Displacement (final displacement - initial displacement)
    
    EndDisp = mean(fid.srl((end-100):end,2)); %EndDisp = mean(fid.srl(peakind:(peakind+100),2));
    InitDisp = mean(fid.srl(1,2));
    
    srldisp = EndDisp - InitDisp;
    
    % Calculate the Resulting SRL Load Curve (assumes 3 degree
    % axial slice in model)
    
    InitLoad = mean(fid.srl(1,3));
    InitTime = (fid.srl(1,1));
    
    TaredLoad = -1*9.81*0.001*(fid.srl(:,3)-InitLoad)/120;
    Time = (fid.srl(:,1)-InitTime);
    peaktime = peaktime_tot - InitTime;    
    %Decimate Data
 
    Time = downsample(Time,10);
    Load = downsample(TaredLoad,10);
        
    
    
    subplot(2,1,2)
    hold on
    plot(Time,-1*(Load)*120*1000/9.81+InitLoad,'r-.')
    
    % Compile and Save Data
    copyfile('TEMPLATE_opt.feb',strcat(pathstr,connt,'TEMPLATE_opt.feb'))
    copyfile('TEMPLATE_opt2.feb',strcat(pathstr,connt,'TEMPLATE_opt2.feb'))
    
    filetoopen = strcat(pathstr,connt,'TEMPLATE_opt.feb');
    feb = fopen(filetoopen,'a')
    filetoopen = strcat(pathstr,connt,'TEMPLATE_opt2.feb');
    febopt2 = fopen(filetoopen)
    
    fprintf(feb,pathstr);
    
    ttline = fgetl(febopt2);
    
    while ischar(ttline)
            ttline = strcat(ttline);
            fprintf(feb,'%s\n',ttline);
            ttline = fgetl(febopt2);
    end
    
    for i = 1:length(Time)
        fprintf(feb,['\n<point>',num2str(Time(i)),',', ...
                    num2str(Load(i)),'</point>']);
    end
    
    fprintf(feb,['\n     </loadcurve>\n   </LoadData>\n</febio_optimize>']);
    fclose(feb)

    
    
    
    
    
    %% Part two_________________________________________
        
    
        
    format long
    


    %Ask user for Geometry
    
    
    %srldisp = input('What is the SRL ramp displacement (mm; >0)? ');
    %diameter = input('What is the diameter (mm)? ');
    %thickness = input('What is the thickness (mm)? ');
    
    Rad = diameter/2;
    
    %Upload positions (currently uses a function calling the generic
    %corrdinates for a 4 mm diam, 2.34 mm thick construct and
    %scales these positions - here there are 20 elements in the
    %radial direction and 1 element in the height (z)). These will
    %then be scaled according user defined parameters.
    xnode_orig = [0.0000000
0.3120967
0.3116690
0.5773789
0.5765877
0.8028688
0.8017685
0.9945352
0.9931722
1.1574517
1.1558654
1.2959306
1.2941546
1.4136378
1.4117004
1.5136888
1.5116144
1.5987322
1.5965412
1.6710191
1.6687290
1.7324630
1.7300887
1.7846902
1.7822444
1.8290834
1.8265767
1.8668176
1.8642592
1.8988917
1.8962893
1.9261547
1.9235150
1.9493282
1.9466567
1.9690257
1.9663272
1.9857686
1.9830471
2.0000000
1.9972591
0.0000000
0.3120967
0.3116690
0.5773789
0.5765877
0.8028688
0.8017685
0.9945352
0.9931722
1.1574517
1.1558654
1.2959306
1.2941546
1.4136378
1.4117004
1.5136888
1.5116144
1.5987322
1.5965412
1.6710191
1.6687290
1.7324630
1.7300887
1.7846902
1.7822444
1.8290834
1.8265767
1.8668176
1.8642592
1.8988917
1.8962893
1.9261547
1.9235150
1.9493282
1.9466567
1.9690257
1.9663272
1.9857686
1.9830471
2.0000000
1.9972591
-5.000000
-5.000000
5.000000
5.000000
-4.9932
-4.9932
4.9932
4.9932];
    
    ynode_orig = [0.0000000
0.0000000
0.0163339
0.0000000
0.0302177
0.0000000
0.0420189
0.0000000
0.0520500
0.0000000
0.0605763
0.0000000
0.0678238
0.0000000
0.0739841
0.0000000
0.0792204
0.0000000
0.0836712
0.0000000
0.0874544
0.0000000
0.0906701
0.0000000
0.0934035
0.0000000
0.0957268
0.0000000
0.0977017
0.0000000
0.0993803
0.0000000
0.1008072
0.0000000
0.1020200
0.0000000
0.1030508
0.0000000
0.1039271
0.0000000
0.1046719
0.0000000
0.0000000
0.0163339
0.0000000
0.0302177
0.0000000
0.0420189
0.0000000
0.0520500
0.0000000
0.0605763
0.0000000
0.0678238
0.0000000
0.0739841
0.0000000
0.0792204
0.0000000
0.0836712
0.0000000
0.0874544
0.0000000
0.0906701
0.0000000
0.0934035
0.0000000
0.0957268
0.0000000
0.0977017
0.0000000
0.0993803
0.0000000
0.1008072
0.0000000
0.1020200
0.0000000
0.1030508
0.0000000
0.1039271
0.0000000
0.1046719
0.2500000
-0.2500000
0.2500000
-0.2500000
-0.26168
-0.26168
0.26168
0.26168];
    
    znode_orig = [0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
0.0000000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
2.3400000
-10.5000000
10.5000000
-10.5000000
10.5000000]; 

    xnode = xnode_orig;
    ynode = ynode_orig;
    znode = znode_orig;
    
    for i = 1:82;
        znode(i) = znode(i) * thickness / 2.34;
        
        if isequal(ynode(i), 0)
            xnode(i) = xnode(i) * Rad / 2;
            
        else
            h = sqrt(xnode(i) ^ 2 + ynode(i) ^2);
            xnode(i) = cosd(3) * h * (Rad / 2);
            ynode(i) = sind(3) * h * (Rad / 2);
            
        end
    end
    
    for i = 83:86;
        znode(i) = znode(i) * thickness / 2.34;
    end
    
    [xnode_orig,ynode_orig,znode_orig,xnode,ynode,znode];
    
    copyfile('TEMPLATE2_srl.feb',strcat(pathstr,connt,'TEMPLATE2_srl.feb'))
    copyfile('TEMPLATE1_srl.feb',strcat(pathstr,connt,'TEMPLATE1_srl.feb'))
    filetoopen1 = strcat(pathstr,connt,'TEMPLATE1_srl.feb')
    feb1 = fopen(filetoopen1,'a');
    filetoopen2 = strcat(pathstr,connt,'TEMPLATE2_srl.feb')
    feb2 = fopen(filetoopen2);

    
    for i = 1:length(xnode)
        fprintf(feb1,'\n %s',['<node id="',num2str(i),'"> ',num2str(xnode(i)),',',num2str(ynode(i)),', ',num2str(znode(i)),'</node>']);
    end
    
   
    tline = fgetl(feb2);
    peaktime = peaktime(1);
    srldisp
    
    platendisp = [num2str(peaktime),',',num2str(-1*srldisp/1000)];
    
    while ischar(tline)
            tline = strcat(tline);
            fprintf(feb1,'\n %s',tline);
            tline = fgetl(feb2);
            
            %Replace XX with peak time, YY with 2*peaktime, and ZZ
            %with the platen displacement parameters
            tline = strrep(tline,'XX',num2str(peaktime));
            tline = strrep(tline,'YY',num2str(2*peaktime));
            
            tline = strrep(tline,'ZZ',platendisp);
        
    end
    
    

    fclose(feb1);

    fclose(feb2);
   


   
    
    
    
    
    

    
    
    
    