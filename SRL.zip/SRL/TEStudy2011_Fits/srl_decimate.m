function [peaktime] = srl_decimate
    
    close all
    clear
    
    %Load File and find Peak Time
    fname=input('\n Please enter data file name: ', 's');       % fname: name of data file
    [pathstr,bname,ext,versn] = fileparts(fname);               %
                                                                % debug parts of filename
    if isequal(pathstr, '')
        connt = '';
    else
        connt = '/';
    end
    
    fid=open(fname);                                            % open data file
    smoothed = filter(ones(1,5)/5,1,(fid.srl(:,3))) ;
    peakind = find(smoothed==max(smoothed));
    %peakind = find(fid.srl(:,3)==max(fid.srl(:,3)));
    peaktime_tot = fid.srl(peakind,1);
    
    %Plot Disp/Load  
    subplot(2,1,1)
    plot(fid.srl(:,1),fid.srl(:,2))
    hold on
    plot(fid.srl(peakind,1),fid.srl(peakind,2),'r+')
    subplot(2,1,2)
    plot(fid.srl(:,1),fid.srl(:,3))
    hold on
    plot(fid.srl(peakind,1),fid.srl(peakind,3),'r+')
    
    % Calculate the Displacement (final displacement - initial displacement)
    
    EndDisp = mean(fid.srl(peakind:(peakind+100),2));
    InitDisp = mean(fid.srl(1,2));
    
    srldisp = EndDisp - InitDisp;
    
    % Calculate the Resulting SRL Load Curve (assumes 3 degree
    % axial slice in model)
    
    InitLoad = mean(fid.srl(1,3));
    InitTime = (fid.srl(1,1));
    
    TaredLoad = -1*9.81*0.001*(fid.srl(:,3)-InitLoad)/120;
    Time = (fid.srl(:,1)-InitTime);
    peaktime = peaktime_tot - InitTime;
    
    %Decimate Data
 
    Time = downsample(Time,10);
    Load = downsample(TaredLoad,10);
        
    
    
    subplot(2,1,2)
    hold on
    plot(Time,-1*(Load)*120*1000/9.81+InitLoad,'r-.')
    
    % Compile and Save Data
    filetoopen = strcat(pathstr,connt,'TEMPLATE_opt.feb');
    feb = fopen(filetoopen,'a')
    
    for i = 1:length(Time)
        fprintf(feb,['\n<point>',num2str(Time(i)),',', ...
                    num2str(Load(i)),'</point>']);
    end
    
    fprintf(feb,['\n     </loadcurve>\n   </LoadData>\n</febio_optimize>']);
    fclose(feb)

        
   
    
    
    
    
    

    
    