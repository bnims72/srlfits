diam0 = 4;
thick0 = 2.3;
srldisp0 = [220.3594
213.2511
220.2152];


for i = 1:3
    
    switch i
        
        case 1
        str='Day0/Tissue_TGFbeta_for_real - D0 - day0 n1/srl.dat';
        path='Day0/Tissue_TGFbeta_for_real - D0 - day0 n1/';
        case 2
        str='Day0/Tissue_TGFbeta_for_real - D0 - day0 n4/srl.dat';
        path='Day0/Tissue_TGFbeta_for_real - D0 - day0 n4/';
        case 3
        str='Day0/Tissue_TGFbeta_for_real - D0 - day0 n3/srl.dat';
        path='Day0/Tissue_TGFbeta_for_real - D0 - day0 n3/';
        
      
    end
    
    fprintf('This is file number ',num2str(i))
    optimizer3(str,srldisp0(i),diam0,thick0,path)
    figure
    
end
