import subprocess as sb

#sb.call(["/Users/nims/Desktop/FEBio-1/febio.osx","-s","/Users/nims/Documents/FEBioPractice/TEStudy2011_Fits/Days/Day14/CABC\ -\ D14\ -\ control\ 120M\ n1/TEMPLATE_opt.feb"])
sb.call(["/Users/nims/Desktop/FEBio-1/febio.osx"])
