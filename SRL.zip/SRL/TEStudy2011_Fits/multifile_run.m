diam = [3.0700
        3.1700
        3.2700
        3.1700
        3.2600
        3.9400
        4.0200
        3.9200
        3.9500
        4.1600
        4.1200
        4.3100
        4.6000
        4.4100
        4.8500
        5.6200
        5.1600
        5.1200
        5.1600
        5.2400
        6.4100
        5.9800
        6.3100
        5.9800
        5.9400
        6.2800];
thick = [2.6700
         2.6700
         2.6200
         2.5800
         2.6800
         3.5200
         3.7700
         3.4700
         3.6400
         3.5900
         3.7800
         3.9300
         4.1600
         3.9100
         4.0500
         4.7300
         4.7300
         4.4800
         3.8500
         3.9500
         4.5600
         5.3000
         5.0600
         5.7200
         5.4000
         5.3800];
srldis = [256.2637
          262.9180
          255.3330
          254.4091
          262.4266
          347.9082
          375.7143
          341.7220
          359.0753
          359.0494
          376.7738
          396.0407
          415.6516
          388.7723
          402.1186
          449.1270
          459.8206
          439.8923
          345.6809
          383.8637
          356.5467
          447.5743
          486.3324
          459.7957
          502.0368
          492.4406];

diam0 = 4;
thick0 = 2.3;
srldisp0 = [220.3594
213.2511
220.2152];


for i = 1:26
    
    switch i
        
        case 1
        str='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day14/cntn1/srl.dat';
        path='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day14/cntn1/';
        case 2
        str='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day14/cntn2/srl.dat';
        path='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day14/cntn2/';
        case 3
        str='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day14/cntn3/srl.dat';
        path='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day14/cntn3/';
        case 4
        str='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day14/cntn4/srl.dat';
        path='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day14/cntn4/';
        case 5
        str='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day14/cntn5/srl.dat';
        path='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day14/cntn5/';
        case 6
        str='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day35/cntn1/srl.dat';
        path='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day35/cntn1/';
        case 7
        str='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day35/cntn2/srl.dat';
        path='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day35/cntn2/';
        case 8
        str='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day35/cntn3/srl.dat';
        path='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day35/cntn3/';
        case 9
        str='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day35/cntn4/srl.dat';
        path='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day35/cntn4/';
        case 10
        str='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day35/cntn5/srl.dat';
        path='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day35/cntn5/';
        case 11
        str='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day56/cntn1/srl.dat';
        path='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day56/cntn1/';
        case 12
        str='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day56/cntn2/srl.dat';
        path='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day56/cntn2/';
        case 13
        str='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day56/cntn3/srl.dat';
        path='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day56/cntn3/';
        
        
        case 14
        str='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day56/cntn4/srl.dat';
        path='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day56/cntn4/';
        case 15
        str='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day56/cntn5/srl.dat';
        path='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day56/cntn5/';
        case 16
        str='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day77/cntn1/srl.dat';
        path='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day77/cntn1/';
        case 17
        str='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day77/cntn2/srl.dat';
        path='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day77/cntn2/';
        
        case 18
        str='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day77/cntn3/srl.dat';
        path='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day77/cntn3/';
        case 19
        str='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day77/cntn4/srl.dat';
        path='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day77/cntn4/';
        case 20
        str='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day77/cntn5/srl.dat';
        path='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day77/cntn5/';
        case 21
        str='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day105/cntn1/srl.dat';
        path='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day105/cntn1/';
        
        case 22
        str='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day105/cntn2/srl.dat';
        path='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day105/cntn2/';
        case 23
        str='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day105/cntn3/srl.dat';
        path='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day105/cntn3/';
        case 24
        str='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day105/cntn4/srl.dat';
        path='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day105/cntn4/';
        case 25
        str='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day105/cntn5/srl.dat';
        path='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day105/cntn5/';
        case 26
        str='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day105/cntn6/srl.dat';
        path='/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day105/cntn6/';
        %case 27
        %str='Day45/TE_TGF-beta - D44 - TGF_beta3_plus n1/srl.dat';
        %path='Day45/TE_TGF-beta - D44 - TGF_beta3_plus n1/';
        %case 27
        %str='Day45/TE_TGF-beta - D44 - TGF_beta3_plus n2/srl.dat';
        %path='Day45/TE_TGF-beta - D44 - TGF_beta3_plus n2/';
        %case 28
        %str='Day45/TE_TGF-beta - D44 - TGF_beta3_plus n3/srl.dat';
        %path='Day45/TE_TGF-beta - D44 - TGF_beta3_plus n3/';
        %case 29
        %str='Day45/TE_TGF-beta - D45 - TGF_beta3_plus n4/srl.dat';
        %path='Day45/TE_TGF-beta - D45 - TGF_beta3_plus n4/';
        %case 30
        %str='Day45/TE_TGF-beta - D45 - TGF_beta3_plus n5/srl.dat';
        %path='Day45/TE_TGF-beta - D45 - TGF_beta3_plus n5/';
        %case 31
        %str='Day45/TE_TGF-beta - D46 - TGF_beta3_plus n6/srl.dat';
        %path='Day45/TE_TGF-beta - D46 - TGF_beta3_plus n6/';
        %case 32
        %str='Day45/TE_TGF-beta - D44 - TGF_beta3_minus n1/srl.dat';
        %path='Day45/TE_TGF-beta - D44 - TGF_beta3_minus n1/';
        %case 33
        %str='Day45/TE_TGF-beta - D44 - TGF_beta3_minus n2/srl.dat';
        %path='Day45/TE_TGF-beta - D44 - TGF_beta3_minus n2/';
        %case 34
        %str='Day45/TE_TGF-beta - D44 - TGF_beta3_minus n3/srl.dat';
        %path='Day45/TE_TGF-beta - D44 - TGF_beta3_minus n3/';
        %case 35
        %str='Day45/TE_TGF-beta - D44 - TGF_beta3_minus n4/srl.dat';
        %path='Day45/TE_TGF-beta - D44 - TGF_beta3_minus n4/';
        %case 36
        %str='Day45/TE_TGF-beta - D45 - TGF_beta3_minus n5/srl.dat';
        %path='Day45/TE_TGF-beta - D45 - TGF_beta3_minus n5/';
        
      
    end
    
    fprintf('This is file number ',num2str(i))
    optimizer3(str,srldis(i),diam(i),thick(i),path)
    figure
    
end


     
     