import matplotlib.pyplot as plt

files = ["/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day14/cntn","/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day35/cntn","/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day56/cntn","/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day77/cntn","/Users/nims/Desktop/FEBioPractice/TEStudy2011_Fits/Chondroitinase/Day105/cntn"]
ending="/TEMPLATE_opt.log"

samples_pergroup = 5

for k in files:
    for i in range(0, samples_pergroup):
        file_k = k+str(i+1)+ending
        print file_k
        f = open(file_k)
        j = 0
        vecfit = []
        vecdata = []
        for line in reversed(f.readlines()):
            j+=1
            if j>14:
                a = line.find('-',2)
                b = line.find(' ',a+2)
                c = line.find('-',b+2)
                d = line.find(' ',c+2)
                if c == -1:
                    break
                else:
                    vecfit.insert(0,float(line[a:b]))
                    vecdata.insert(0,float(line[c:d]))
        plt.plot(vecfit,color='r')
        plt.plot(vecdata,color='b')
        plt.show()
